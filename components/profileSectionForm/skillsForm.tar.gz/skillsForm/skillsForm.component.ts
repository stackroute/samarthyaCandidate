import { SkillsFormRender } from './skillFormRender/skillsFormRender.component';
import { Component, OnInit, Inject } from '@angular/core';
import { MdDialog, MdDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Component({
  selector: 'skills-form',
  templateUrl: './skillsForm.component.html',
  styleUrls: ['./skillsForm.component.css']
})
export class SkillsForm implements OnInit {

  public userForm: FormGroup;
  public infoobj: any;
  public timer: any;
  public loading = false;
  public render : SkillsFormRender;
  public skillsValue:any;
public results:any=[];
  public skills:any=[];

  // public skills : Array<SkillsFormRender> = [];
 // public skills : any;
  levels = [
    {name : 'BEGINNER', value : 'Beginner'},
    {name : 'MODERATE', value : 'Moderate'},
     {name : 'EXPERT', value : 'Expert'},

  ] ;
  constructor(
    @Inject(FormBuilder) fb: FormBuilder,
    public dialogRef: MdDialogRef<SkillsForm>,private http:Http
  ) {
    // this.userForm = fb.group({
    //   name: [this.dialogRef.config.data.name, [Validators.required]],
    //   experience: [this.dialogRef.config.data.experience, [Validators.required, Validators.pattern('[0-9]{0,3}')]],
    //   expertise: [this.dialogRef.config.data.expertise, [Validators.required, Validators.pattern('^[a-zA-Z\\s]*$')]],
   // });
  }

  ngOnInit() {
    this.skillsValue=this.dialogRef.config.data;
       
  }
  

  onSave(event:any) {
    console.log(this.results);
    let sectionName="skills";
    let currentuser=JSON.parse(localStorage.getItem('currentUser'));
    this.http.patch('/profile',{sectionName:sectionName,username:currentuser.username,data:this.results})
    .subscribe((res)=>{
        console.log(res.json)
    },(err)=>{

    });

  }
  onAdd() {
   
     this.skills.push({name:'',expertise:'',experience:''});
   
  }




  
}

